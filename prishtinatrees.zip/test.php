<table  class="table table-bordered table-striped table-hover text-center">
				<thead>
					<tr>
						<th scope="col">Ikona</th>
						<th scope="col">Përshkrimi</th>
						<th scope="col">Shfaqe</th>
					</tr>
				</thead>
				<tbody>
					<tr scope="row">
						<td><i class="fas fa-tree text-success"></i></td>
						<td>Dru</td>
						<td><input id="toggleDrunjet" type="checkbox" checked data-toggle="toggle" data-size="sm"></td>
					</tr>
					<tr scope="row">
						<td><i class="fas fa-trash-alt"></i></td>
						<td>Shportë</td>
						<td><input id="toggleShportat" type="checkbox" checked data-toggle="toggle" data-size="sm"></td>
					</tr>
					<tr scope="row">
						<td><i class="fas fa-volume-up text-info"></i></td>
						<td>Niveli i zhurmës</td>
						<td><input id="toggleZhurmen" type="checkbox" checked data-toggle="toggle" data-size="sm"></td>
					</tr>
					<tr scope="row">
						<td><i class="fas fa-bolt text-warning"></i></td>
						<td>Shtyllë elektrike</td>
						<td><input id="toggleShtyllat" type="checkbox" checked data-toggle="toggle" data-size="sm"></td>
					</tr>
				</tbody>
			</table>